WHIKoperator - фреймворк для работы с камерой HV в Gravity-core
